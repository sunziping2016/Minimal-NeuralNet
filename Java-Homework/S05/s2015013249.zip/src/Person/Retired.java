package Person;

/**
 * Created by sun on 4/2/16.
 *
 * Retired class.
 */
public class Retired extends Person {
    @Override
    public String introduceSelf() {
        return "I am a retired person.";
    }
}
