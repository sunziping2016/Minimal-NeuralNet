package Person;

/**
 * Created by sun on 4/2/16.
 *
 * Employee class.
 */
public class Employee extends Person {
    @Override
    public String introduceSelf() {
        return "I am an employee";
    }
}
