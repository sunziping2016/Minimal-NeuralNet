package Person;

/**
 * Created by sun on 4/2/16.
 *
 * Person class.
 */
public class Person {
    public String introduceSelf() {
        return "I am a person.";
    }
}
