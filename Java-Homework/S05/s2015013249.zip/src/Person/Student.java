package Person;

/**
 * Created by sun on 4/2/16.
 *
 * Student class.
 */
public class Student extends Person {
    @Override
    public String introduceSelf() {
        return "I am a student.";
    }
}
