package Shape;

/**
 * Created by sun on 4/2/16.
 *
 * Shape class.
 */
abstract public class Shape {
    protected double area;
    abstract public double getArea();
}
