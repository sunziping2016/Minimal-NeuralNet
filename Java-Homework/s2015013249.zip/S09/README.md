# About
It's an online Tic-Tac-Toe game written in Java as my homework.

A server is hosted on `tencent.sunziping.com`. You can try it yourself.

Continuous unknown connections annoy me a lot. I decide to add a fire wall to protect my server
from being attacked. F**k the attackers!
